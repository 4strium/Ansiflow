$$$$$$$$\                                $$\                     $$\        $$$$$$\   $$$$$$\  
\__$$  __|                               \__|                    $$ |      $$  __$$\ $$$ __$$\ 
   $$ | $$$$$$\   $$$$$$\  $$$$$$\$$$$\  $$\ $$$$$$$\   $$$$$$\  $$ |      \__/  $$ |$$$$\ $$ |
   $$ |$$  __$$\ $$  __$$\ $$  _$$  _$$\ $$ |$$  __$$\  \____$$\ $$ |       $$$$$$  |$$\$$\$$ |
   $$ |$$$$$$$$ |$$ |  \__|$$ / $$ / $$ |$$ |$$ |  $$ | $$$$$$$ |$$ |      $$  ____/ $$ \$$$$ |
   $$ |$$   ____|$$ |      $$ | $$ | $$ |$$ |$$ |  $$ |$$  __$$ |$$ |      $$ |      $$ |\$$$ |
   $$ |\$$$$$$$\ $$ |      $$ | $$ | $$ |$$ |$$ |  $$ |\$$$$$$$ |$$ |      $$$$$$$$\ \$$$$$$  /
   \__| \_______|\__|      \__| \__| \__|\__|\__|  \__| \_______|\__|      \________| \______/ 

Lancer une partie :
➤ Ouvrir un terminal dans le dossier courant.
➤ Faire en sorte que la fenêtre du terminal prenne toute la largeur et la longueur de l'écran, pour apprécier pleinement.
➤ Exécuter le programme "terminal20.py" au moyen de Python
   
Commandes :
➥ Déplacement dans le labyrinthe :
	➤ Z - Avancer
	➤ S - Reculer
	➤ Q - Tourner la tête vers la gauche
	➤ D - Tourner la tête vers la droite
➥ Combat avec les zombies :
	➤ ESPACE - Tirer
➥ Dialogues (choix multiples) :
	➤ Q - Déplacer le curseur à gauche
	➤ D - Déplacer le curseur à droite
	➤ ESPACE - Confirmer sa réponse
➥ Memory
	➤ Z - Déplacer le curseur en haut
	➤ S - Déplacer le curseur en bas
	➤ Q - Déplacer le curseur à gauche
	➤ D - Déplacer le curseur à droite
	➤ ESPACE - Confirmer sa réponse
	
Romain MELLAZA - 2025
